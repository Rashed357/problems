from django.db import models

class CodeforcesUser(models.Model):
    
    
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='profile_images/', blank=True, null=True)  # Requires MEDIA setup
    handle = models.CharField(max_length=50, unique=True)
    age = models.IntegerField()
    address = models.TextField()
    email = models.EmailField(unique=True)
    session = models.CharField(max_length=20)  # Example: "2020-2024"
    roll_number = models.CharField(max_length=20)
    rating = models.IntegerField(default=0)
    last_updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} ({self.handle}) - {self.rating}"
