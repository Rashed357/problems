from rest_framework import serializers
from leaderboard.models import CodeforcesUser
from django.utils import timezone


class CodeforcesUserSerializer(serializers.Serializer):
    
    id = serializers.IntegerField(read_only=True)
    name = serializers.CharField(max_length=100)
    image = serializers.ImageField(required=False)
    handle = serializers.CharField(max_length=50)
    age = serializers.IntegerField()
    address = serializers.CharField()
    email = serializers.EmailField()
    session = serializers.CharField(max_length=20)
    roll_number = serializers.CharField(max_length=20)
    rating = serializers.IntegerField(read_only=True)  # Set to read-only
    last_updated = serializers.DateTimeField(read_only=True)  # Set to read-only

    def create(self, validated_data):
        """Create a new CodeforcesUser instance"""
        # You might want to set rating here after fetching it from Codeforces
        from leaderboard.utils import fetch_codeforces_rating  # Assuming you have a function for this
        handle = validated_data.get('handle')
        rating_data = fetch_codeforces_rating(handle)  # This fetches rating from Codeforces
        
        # Add rating to validated_data before saving
        validated_data['rating'] = rating_data
        validated_data['last_updated'] = timezone.now()  # Set current time
        
        return CodeforcesUser.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """Update an existing CodeforcesUser instance"""
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance
