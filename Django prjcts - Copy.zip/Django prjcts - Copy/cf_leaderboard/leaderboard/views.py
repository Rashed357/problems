from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from leaderboard.models import CodeforcesUser
from leaderboard.serializers import CodeforcesUserSerializer
from .utils import fetch_codeforces_rating

class LeaderboardListView(APIView):
    """Handles GET and POST requests for the leaderboard"""

    def get(self, request):
        """Retrieve all users, update their ratings, and return sorted list"""
        # Fetch all users and update their ratings
        users = CodeforcesUser.objects.all()
        for user in users:
            new_rating = fetch_codeforces_rating(user.handle)
            if new_rating is not None and new_rating != user.rating:
                user.rating = new_rating
                user.save()

        # Serialize the users data and return as response
        users = CodeforcesUser.objects.all().order_by('-rating')
        serializer = CodeforcesUserSerializer(users, many=True)
        return Response(serializer.data)

    def post(self, request):
        """Create a new user and fetch their rating from Codeforces"""
        # Deserialize the incoming data
        print(request.data)
        serializer = CodeforcesUserSerializer(data=request.data)
        
        if serializer.is_valid():
            # Get the Codeforces handle from the data
            handle = serializer.validated_data['handle']
            rating = fetch_codeforces_rating(handle)
            print(f"Rating = {rating}")
            if rating is None:
                return Response({'error': 'Invalid Codeforces handle or failed to fetch rating'}, status=status.HTTP_400_BAD_REQUEST)

            # Add the fetched rating to the serialized data and save
            serializer.validated_data['rating'] = rating
            print(serializer)
            print("Aiche")
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LeaderboardDetailView(APIView):
    """Handles GET, PUT, and DELETE requests for a specific user"""
    print("saboj")
    def get(self, request, pk):
        """Retrieve a single user by their ID"""
        try:
            user = CodeforcesUser.objects.get(pk=pk)
        except CodeforcesUser.DoesNotExist:
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)

        serializer = CodeforcesUserSerializer(user)
        return Response(serializer.data)

    def put(self, request, pk):
        """Update a specific user's information"""
        try:
            user = CodeforcesUser.objects.get(pk=pk)
        except CodeforcesUser.DoesNotExist:
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)

        serializer = CodeforcesUserSerializer(user, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        """Delete a specific user"""
        print(pk)
        try:
            user = CodeforcesUser.objects.get(pk=pk)
        except CodeforcesUser.DoesNotExist:
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)

        user.delete()
        return Response({'message': 'User deleted successfully'}, status=status.HTTP_204_NO_CONTENT)
