import requests
def fetch_codeforces_rating(handle):
    """Fetch the latest rating of a Codeforces user."""
    url = f"https://codeforces.com/api/user.rating?handle={handle}"
    
    # Make the API request
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        # print(data)
        if data["status"] == "OK":
            # Return the latest rating from the result
            # Assuming the last entry is the most recent
            if data["result"]:
                latest_rating = data["result"][-1]['newRating']
                # print(latest_rating)
                return latest_rating
            else:
                return None
        else:
            print("Error fetching rating:", data["comment"])
            return None
    else:
        print(f"Failed to fetch data. HTTP Status Code: {response.status_code}")
        return None
