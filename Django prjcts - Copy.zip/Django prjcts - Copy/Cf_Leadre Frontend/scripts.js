document.addEventListener("DOMContentLoaded", () => {
    const leaderboardBody = document.getElementById("leaderboardData");
    const userForm = document.getElementById("userForm");

    // Function to fetch and display leaderboard data
    async function fetchLeaderboard() {
        try {
            const response = await fetch("http://127.0.0.1:8000/api/leaderboard/");
            const users = await response.json();

            if (!response.ok) {
                throw new Error("Failed to fetch leaderboard");
            }

            leaderboardBody.innerHTML = ""; // Clear existing table

            users.forEach((user, index) => {
                const row = document.createElement("tr");
                row.innerHTML = `
                    <td>${index + 1}</td>  
                    <td>${user.name}</td>
                    <td>${user.handle}</td>
                    <td>${user.rating}</td>
                    <td>${user.roll_number || "Not Get"}</td> 
                    <td>${user.session || "N/A"}</td>
                    <td><button onclick="deleteUser(${user.id})" class="delete-btn">❌</button></td>
                `;
                leaderboardBody.appendChild(row);
            });
        } catch (error) {
            console.error("Error fetching leaderboard:", error);
            alert("Failed to load leaderboard. Check API or server.");
        }
    }

    // Function to add a new user
    async function addUser(event) {
        event.preventDefault(); // Prevent form submission

        const newUser = {
            name: document.getElementById("name").value,
            handle: document.getElementById("handle").value,
            age: document.getElementById("age").value,
            address: document.getElementById("address").value,
            email: document.getElementById("email").value,
            session: document.getElementById("session").value,
            roll_number: document.getElementById("rollNumber").value
        };

        try {
            const response = await fetch("http://127.0.0.1:8000/api/leaderboard/", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(newUser),
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || "Failed to add user");
            }

            alert("User added successfully!");
            userForm.reset();
            fetchLeaderboard(); // Refresh leaderboard
        } catch (error) {
            console.error("Error adding user:", error);
            alert("Failed to add user. Please check input data.");
        }
    }

    // Function to delete a user
    async function deleteUser(userId) {
        if (!confirm("Are you sure you want to delete this user?")) return;

        try {
            const response = await fetch(`http://127.0.0.1:8000/api/leaderboard/${userId}/`, {
                method: "DELETE",
            });

            if (!response.ok) {
                throw new Error("Failed to delete user");
            }

            alert("User deleted successfully!");
            fetchLeaderboard(); // Refresh leaderboard
        } catch (error) {
            console.error("Error deleting user:", error);
            alert("Failed to delete user.");
        }
    }

    // Attach event listener to the form
    userForm.addEventListener("submit", addUser);

    // Fetch leaderboard on page load
    fetchLeaderboard();
});
